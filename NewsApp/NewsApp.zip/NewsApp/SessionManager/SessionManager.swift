//
//  SessionManager.swift
//

import SwiftUI

@MainActor
protocol SessionManager {
    var isAuthenticated: Bool { get }
    var user: SupabaseUser? { get }
    func startSession(response: AuthResponse)
    func logout()
    func restoreSession()
}

@MainActor
final class SessionManagerImp: SessionManager, ObservableObject {
    @Published var isAuthenticated: Bool = false
    @Published var user: SupabaseUser?
    
    private let tokenStorage: TokenStorage
    
    init(
        tokenStorage: TokenStorage
    ) {
        self.tokenStorage = tokenStorage
    }
    
    func startSession(response: AuthResponse) {
        tokenStorage.save(response.access_token, for: "access_token")
        
        if let refresh = response.refresh_token {
            tokenStorage.save(refresh, for: "refresh_token")
        }
        
        if let id = response.user?.id {
            tokenStorage.save(id, for: "user_id")
        }
        
        if let email = user?.email {
            tokenStorage.save(email, for: "email")
        }
        
        user = response.user
        isAuthenticated = true
        
    }
    
    func logout() {
        tokenStorage.clear()
        isAuthenticated = false
        user = nil
    }
    
    func restoreSession() {
        if tokenStorage.get("access_token") != nil {
            isAuthenticated = true
        }
    }
    
    
}
