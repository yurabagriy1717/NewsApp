//
//  SupabaseConstants.swift
//

import Foundation

enum SupabaseConstants {
    static let projectURL = "https://ycticsgaftrxrrvxomeq.supabase.co"
    static let anonKey = "sb_publishable_G-xf6xk5bcWhDj_jR74X0g_NuJQ3OyS"
}

