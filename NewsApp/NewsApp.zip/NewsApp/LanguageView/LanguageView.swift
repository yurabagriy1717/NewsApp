//
//  LanguageView.swift
//

import SwiftUI

struct LanguageView: View {
    var body: some View {
        Text("hello world")
    }
}

#Preview {
    LanguageView()
}
