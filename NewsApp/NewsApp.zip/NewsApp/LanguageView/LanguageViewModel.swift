//
//  LanguageViewModel.swift
//

import Foundation

class LanguageViewModel: ObservableObject {
    
}
