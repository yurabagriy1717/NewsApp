//
//  AboutView.swift
//

import SwiftUI

struct AboutView: View {
    var body: some View {
        Text("About")
    }
}


#Preview {
    AboutView()
}
