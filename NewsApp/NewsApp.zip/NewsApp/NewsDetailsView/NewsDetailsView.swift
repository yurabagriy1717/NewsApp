//
//  NewsDetailsView.swift
//

import SwiftUI

struct NewsDetailsView: View {
    let article: NewsModel
    
    var body: some View {
        VStack {
            ScrollView {
                AsyncImage(url: URL(string: article.urlToImage ?? "")) { image in
                    image
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 250)
                        .clipped()
                        .cornerRadius(12)
                } placeholder: {
                    ProgressView()
                        .frame(height: 200)
                        .frame(maxWidth: .infinity)
                        .background(Color(.systemGray6))
                        .cornerRadius(12)
                }
                Text(article.title)
                    .font(.title3)
                    .fontWeight(.semibold)
                    .multilineTextAlignment(.leading)
                    .padding(.horizontal)
                HStack {
                    Text(article.author ?? "")
                    Spacer()
                    Text(article.sourceName)
                }
                .font(.subheadline)
                .foregroundColor(.secondary)
                .padding(.horizontal)
                Text(article.publishedAt)
                    .font(.caption)
                    .foregroundColor(.gray)
                    .padding(.horizontal)
                Text(article.descprition ?? "")
                    .font(.body)
                    .padding(.horizontal)
                    .padding(.top, 8)
            }
        }
    }
}


#Preview {
    NewsDetailsView(
        article: NewsModel(
            author: "esgverfvcesa",
            title: "Apple презентувала MacBook Pro M3 💻",
            descprition: "Швидший, довше тримає батарею.",
            url: "gsvearfca",
            urlToImage: "https://picsum.photos/400/200?1",
            publishedAt: "2025-11-03T08:00:00Z",
            sourceName: "gfdvsrfvcer")
    )
}
