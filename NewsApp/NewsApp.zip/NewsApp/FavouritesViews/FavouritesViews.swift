//
//  FavouritesViews.swift
//

import SwiftUI

struct FavouritesViews: View {
    var body: some View {
        Text("FavouritesViews")
    }
}

#Preview {
    FavouritesViews()
}
