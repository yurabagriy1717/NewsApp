//
//  UserProfile.swift
//

import Foundation

struct UserProfile: Codable {
    let id: String
    let first_name: String
    let last_name: String
}
